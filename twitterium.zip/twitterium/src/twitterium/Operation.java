package twitterium;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Operation extends HttpServlet{
	public Operation() {
		
	}
	
	
	public float calcul(int a, int b, String op) {
		float res = 0;
		if(op.equals("add"))
			res = a + b;
		else if(op.equals("sub"))
			res = a - b;
		else if(op.equals("mult"))
			res = a * b;
		else if(op.equals("div"))
			res = (float)a / b;
		else res = 0;
		
		return res;
	}
	
	protected void doGet(HttpServletRequest request,
			 HttpServletResponse response) throws ServletException, IOException {
			 
				Map<String, String[]> pars = request.getParameterMap();
				float result;
				//test if contains a and b and op
				if(pars.containsKey("a") && pars.containsKey("b") && pars.containsKey("op")){
					String valA = request.getParameter("a");
					String valB = request.getParameter("b");
					String op = request.getParameter("op");
					
					result = calcul(Integer.parseInt(valA), Integer.parseInt(valB), op);
					
				 	response.setContentType( " text / plain " );
					PrintWriter out = response.getWriter ();
					out.println( result );
				}else{
					response.setContentType( " text / plain " );
					PrintWriter out = response.getWriter ();
					out.println( "mauvaises valeurs" );
				}
	}
	
}
